#!/usr/bin/env bash
# =============================================================================
# 单章闭环式小说生成安卓APP - 一键打包脚本 (Linux / macOS)
#
# 用法：
#   chmod +x build_apk.sh
#   ./build_apk.sh
#
# 功能：
#   1. 检测 JDK 17（新版 Android Gradle Plugin 要求 JDK 17，Java 11 会失败）
#   2. 检测 Android SDK，缺失时自动下载命令行工具并安装必要组件
#   3. 生成 Gradle Wrapper（缺失时）
#   4. 执行 assembleDebug 产出 app-debug.apk
#
# 环境变量（可选）：
#   ANDROID_HOME  指定 Android SDK 目录，默认 ~/Android/Sdk
#   JAVA_HOME     指定 JDK 17 路径
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ---------- 颜色输出 ----------
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
fail()  { echo -e "${RED}[FAIL]${NC} $*"; exit 1; }

# ---------- 1. JDK 17 检测 ----------
info "检查 JDK 版本..."
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/java" ]; then
    JAVA_CMD="$JAVA_HOME/bin/java"
else
    JAVA_CMD="java"
fi

if ! command -v "$JAVA_CMD" >/dev/null 2>&1; then
    fail "未找到 Java。请安装 JDK 17（推荐：https://adoptium.net）"
fi

JAVA_VERSION=$("$JAVA_CMD" -version 2>&1 | head -1 | sed -E 's/.*version "([0-9]+).*/\1/')
info "检测到 Java 主版本: $JAVA_VERSION"
if [ "$JAVA_VERSION" -lt 17 ]; then
    fail "需要 JDK 17 及以上（当前为 $JAVA_VERSION）。请升级 JDK 后重试。"
fi

# ---------- 2. Android SDK 检测 / 安装 ----------
ANDROID_HOME="${ANDROID_HOME:-$HOME/Android/Sdk}"
export ANDROID_HOME

COMPILE_SDK=34
BUILD_TOOLS="34.0.0"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"

has_sdk() {
    [ -d "$ANDROID_HOME/platforms/android-$COMPILE_SDK" ] && \
    [ -d "$ANDROID_HOME/build-tools/$BUILD_TOOLS" ]
}

if has_sdk; then
    info "Android SDK 已就绪: $ANDROID_HOME"
else
    warn "Android SDK 缺失或组件不全，开始自动安装到 $ANDROID_HOME ..."
    mkdir -p "$ANDROID_HOME"

    if [ ! -x "$SDKMANAGER" ]; then
        info "下载 Android 命令行工具..."
        TMP_ZIP=$(mktemp --suffix=.zip)
        if command -v curl >/dev/null 2>&1; then
            curl -fsSL -o "$TMP_ZIP" "$CMDLINE_TOOLS_URL"
        elif command -v wget >/dev/null 2>&1; then
            wget -q -O "$TMP_ZIP" "$CMDLINE_TOOLS_URL"
        else
            fail "需要 curl 或 wget 下载 Android SDK"
        fi
        info "解压命令行工具..."
        TMP_DIR=$(mktemp -d)
        unzip -q "$TMP_ZIP" -d "$TMP_DIR"
        mkdir -p "$ANDROID_HOME/cmdline-tools"
        mv "$TMP_DIR/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
        rm -rf "$TMP_DIR" "$TMP_ZIP"
        info "命令行工具安装完成"
    fi

    info "安装 platform-tools / platform / build-tools（首次需接受许可）..."
    yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
    "$SDKMANAGER" "platform-tools" "platforms;android-$COMPILE_SDK" "build-tools;$BUILD_TOOLS"
    info "Android SDK 组件安装完成"
fi

# ---------- 3. Gradle Wrapper 准备 ----------
if [ ! -x "$SCRIPT_DIR/gradlew" ]; then
    warn "gradlew 缺失，尝试用系统 gradle 生成 wrapper..."
    if command -v gradle >/dev/null 2>&1; then
        gradle wrapper --gradle-version 8.5 || true
    else
        info "未找到系统 gradle，下载 Gradle 8.5 生成 wrapper..."
        GRADLE_ZIP_URL="https://services.gradle.org/distributions/gradle-8.5-bin.zip"
        TMP_ZIP=$(mktemp --suffix=.zip)
        TMP_DIR=$(mktemp -d)
        curl -fsSL -o "$TMP_ZIP" "$GRADLE_ZIP_URL"
        unzip -q "$TMP_ZIP" -d "$TMP_DIR"
        "$TMP_DIR/gradle-8.5/bin/gradle" wrapper --gradle-version 8.5
        rm -rf "$TMP_DIR" "$TMP_ZIP"
    fi
fi

# ---------- 4. 构建 ----------
info "开始构建 debug APK（首次构建需下载依赖，耗时较长）..."
./gradlew --no-daemon assembleDebug
APK="$SCRIPT_DIR/app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK" ]; then
    info "构建成功！"
    echo
    echo -e "${GREEN}APK 位置: $APK${NC}"
    echo "安装到手机：将手机开启 USB 调试并连接，或直接把 APK 传到手机点击安装。"
    echo "安装后请在 APP「服务设置」中填写后端电脑的局域网 IP，如 http://192.168.x.x:8000"
else
    fail "构建未产出 APK，请检查上方错误信息。"
fi
