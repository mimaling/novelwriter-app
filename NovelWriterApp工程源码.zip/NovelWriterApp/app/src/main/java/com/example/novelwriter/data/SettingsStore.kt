package com.example.novelwriter.data

import android.content.Context
import android.content.SharedPreferences

/**
 * 轻量本地配置存储：记住模型接口地址、API Key、模型名等，重启不丢失。
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("novel_writer_settings", Context.MODE_PRIVATE)

    /** 大模型接口地址（OpenAI 兼容），如 https://api.deepseek.com 或 https://dashscope.aliyuncs.com/compatible-mode/v1 */
    var llmBaseUrl: String
        get() = prefs.getString(KEY_LLM_BASE_URL, DEFAULT_LLM_BASE_URL) ?: DEFAULT_LLM_BASE_URL
        set(value) = prefs.edit().putString(KEY_LLM_BASE_URL, value).apply()

    /** API Key */
    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    /** 模型名 */
    var modelName: String
        get() = prefs.getString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME) ?: DEFAULT_MODEL_NAME
        set(value) = prefs.edit().putString(KEY_MODEL_NAME, value).apply()

    companion object {
        private const val KEY_LLM_BASE_URL = "llm_base_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_MODEL_NAME = "model_name"
        private const val DEFAULT_LLM_BASE_URL = "https://api.deepseek.com"
        private const val DEFAULT_MODEL_NAME = "deepseek-chat"
    }
}
