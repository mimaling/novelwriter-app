package com.example.novelwriter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.novelwriter.data.MemeStore
import com.example.novelwriter.data.NovelStore
import com.example.novelwriter.data.SettingsStore
import com.example.novelwriter.ui.GenerateScreen
import com.example.novelwriter.ui.InitScreen
import com.example.novelwriter.ui.MemeScreen
import com.example.novelwriter.ui.ProgressScreen
import com.example.novelwriter.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = applicationContext
        MainViewModelFactory(
            SettingsStore(app),
            NovelStore(app),
            MemeStore(app),
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NovelWriterApp(viewModel)
        }
    }
}

@Composable
fun NovelWriterApp(viewModel: MainViewModel) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    TabItem(0, Icons.Filled.Settings, "服务设置"),
                    TabItem(1, Icons.Filled.Home, "全书初始化"),
                    TabItem(2, Icons.Filled.Edit, "生成章节"),
                    TabItem(3, Icons.Filled.Visibility, "进度与伏笔"),
                    TabItem(4, Icons.Filled.Star, "梗库"),
                )
                items.forEach { item ->
                    NavigationBarItem(
                        selected = selectedTab == item.index,
                        onClick = { selectedTab = item.index },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                    )
                }
            }
        },
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)
        when (selectedTab) {
            0 -> SettingsScreen(viewModel, modifier)
            1 -> InitScreen(viewModel, modifier)
            2 -> GenerateScreen(viewModel, modifier)
            3 -> ProgressScreen(viewModel, modifier)
            else -> MemeScreen(viewModel, modifier)
        }
    }
}

data class TabItem(val index: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String)
