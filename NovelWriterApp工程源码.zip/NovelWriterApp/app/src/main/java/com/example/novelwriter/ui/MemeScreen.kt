package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel
import com.example.novelwriter.data.MemeItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 界面五：本地梗库（抓取热梗入库 / 手动添加 / 查看删除） */
@Composable
fun MemeScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("本地梗库", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "融梗素材收集库：一键抓取内置经典梗 + 微博/抖音/百度/头条/知乎/B站/快手/贴吧当日热榜入库；也可手动添加。生成章节时自动从库中取材，优先使用未用过的梗。",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))

        // ---- 抓取热梗入库 ----
        Button(
            onClick = { viewModel.collectHotMemes() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.collectMemeLoading,
        ) {
            if (viewModel.collectMemeLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("一键抓取入库（经典梗 + 多平台热榜）")
            }
        }
        Spacer(Modifier.height(12.dp))

        // ---- 手动添加 ----
        OutlinedTextField(
            value = viewModel.newMemeText,
            onValueChange = { viewModel.newMemeText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("手动添加梗（如：显眼包 / 六边形战士）") },
            singleLine = true,
        )
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = { viewModel.addMeme() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.collectMemeLoading && viewModel.newMemeText.isNotBlank(),
        ) {
            Text("添加进库")
        }

        viewModel.noticeMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "梗库（共${viewModel.memeLibrary.size}条）",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(8.dp))

        if (viewModel.memeLibrary.isEmpty()) {
            Text(
                "暂无梗，点上方按钮抓取（含经典梗与各平台热榜）或手动添加",
                style = MaterialTheme.typography.bodyMedium,
            )
        } else {
            viewModel.memeLibrary.forEach { item ->
                MemeRow(item, onDelete = { viewModel.deleteMeme(item.content) })
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

@Composable
private fun MemeRow(item: MemeItem, onDelete: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.weight(1f)) {
            Text(item.content, style = MaterialTheme.typography.bodyLarge)
            Text(
                "${if (item.source == "manual") "手动添加" else "热梗抓取"} · 已用${item.usedCount}次 · ${timeText(item.collectedAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        TextButton(onClick = onDelete) {
            Text("删除", color = MaterialTheme.colorScheme.error)
        }
    }
}

private fun timeText(timestamp: Long): String {
    if (timestamp <= 0L) return "-"
    return try {
        SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))
    } catch (e: Exception) {
        "-"
    }
}
