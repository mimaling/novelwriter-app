package com.example.novelwriter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.novelwriter.data.NovelEngine
import com.example.novelwriter.data.NovelStore
import com.example.novelwriter.data.SettingsStore

class MainViewModelFactory(
    private val settings: SettingsStore,
    private val novelStore: NovelStore,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(
            engine = NovelEngine(novelStore, settings),
            settings = settings,
        ) as T
    }
}
