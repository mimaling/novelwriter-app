package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel
import com.example.novelwriter.data.NovelCategories

/** 界面二：全书初始化（分类多选 / 设定润色 / 生成大纲） */
@Composable
fun InitScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("初始化全书设定", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "选定分类（可多选），填写设定后可选润色，再锁定设定、生成大纲。",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))

        // ---- 分类多选 ----
        Text("作品分类（可多选）", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        Column {
            NovelCategories.all.chunked(3).forEach { rowCats ->
                Row {
                    rowCats.forEach { cat ->
                        FilterChip(
                            selected = cat in viewModel.selectedCategories,
                            onClick = { viewModel.toggleCategory(cat) },
                            label = { Text(cat) },
                            modifier = Modifier.padding(end = 6.dp, bottom = 6.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // ---- 三栏设定（每栏带润色按钮） ----
        SettingField(
            label = "世界观设定",
            value = viewModel.initBookSetting,
            onValueChange = { viewModel.initBookSetting = it },
            onPolish = { viewModel.polishField("book") },
            polishing = viewModel.polishLoading && viewModel.polishTarget == "book",
        )
        Spacer(Modifier.height(12.dp))
        SettingField(
            label = "人物设定",
            value = viewModel.initCharacterSetting,
            onValueChange = { viewModel.initCharacterSetting = it },
            onPolish = { viewModel.polishField("character") },
            polishing = viewModel.polishLoading && viewModel.polishTarget == "character",
        )
        Spacer(Modifier.height(12.dp))
        SettingField(
            label = "主线剧情方向",
            value = viewModel.initMainPlot,
            onValueChange = { viewModel.initMainPlot = it },
            onPolish = { viewModel.polishField("plot") },
            polishing = viewModel.polishLoading && viewModel.polishTarget == "plot",
        )

        // ---- 润色结果预览（可编辑） ----
        if (viewModel.polishResult.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("润色结果预览（可直接修改）", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.polishResult,
                onValueChange = { viewModel.polishResult = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(6.dp))
            Row {
                Button(
                    onClick = { viewModel.applyPolish() },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("采用此结果")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { viewModel.dismissPolish() },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("放弃")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { viewModel.initNovel() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.initLoading,
        ) {
            if (viewModel.initLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("锁定设定")
            }
        }
        viewModel.initMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }

        Spacer(Modifier.height(16.dp))
        Text("生成全书大纲", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            "基于已锁定的分类与设定生成章节级大纲，确认后后续章节将按大纲推进。",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { viewModel.generateOutline() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.outlineLoading && viewModel.selectedCategories.isNotEmpty(),
        ) {
            if (viewModel.outlineLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("生成大纲")
            }
        }

        // ---- 大纲结果预览（可编辑） ----
        if (viewModel.outlineResult.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("大纲预览（可直接修改）", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.outlineResult,
                onValueChange = { viewModel.outlineResult = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(6.dp))
            Row {
                Button(
                    onClick = { viewModel.applyOutline() },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("采用此大纲")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { viewModel.dismissOutline() },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("放弃")
                }
            }
        }

        viewModel.noticeMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun SettingField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    onPolish: () -> Unit,
    polishing: Boolean,
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text(label) },
            minLines = 3,
        )
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onPolish, enabled = !polishing) {
                if (polishing) {
                    CircularProgressIndicator(modifier = Modifier.height(14.dp))
                    Spacer(Modifier.width(6.dp))
                }
                Text("按所选分类润色此栏")
            }
        }
    }
}
