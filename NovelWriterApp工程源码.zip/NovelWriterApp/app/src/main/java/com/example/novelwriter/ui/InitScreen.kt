package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel

/** 界面二：全书初始化（仅第一次调用） */
@Composable
fun InitScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("初始化全书设定", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "仅需在开始写书时调用一次。设定会永久锁定，之后逐章生成均以此为准。",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = viewModel.initBookSetting,
            onValueChange = { viewModel.initBookSetting = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("世界观设定") },
            minLines = 3,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = viewModel.initCharacterSetting,
            onValueChange = { viewModel.initCharacterSetting = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("人物设定") },
            minLines = 3,
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = viewModel.initMainPlot,
            onValueChange = { viewModel.initMainPlot = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("主线剧情方向") },
            minLines = 3,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { viewModel.initNovel() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.initLoading,
        ) {
            if (viewModel.initLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("锁定设定并开始")
            }
        }
        viewModel.initMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}
