package com.example.novelwriter.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// ==================== 大模型接口（OpenAI 兼容） ====================

@Serializable
data class ChatMessage(
    val role: String,
    val content: String,
)

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.65,
    @SerialName("max_tokens") val maxTokens: Int = 3600,
)

@Serializable
data class ChatResponse(
    val choices: List<ChatChoice> = emptyList(),
    val error: ChatError? = null,
)

@Serializable
data class ChatChoice(
    val message: ChatMessage = ChatMessage("assistant", ""),
)

@Serializable
data class ChatError(
    val message: String = "",
    val type: String = "",
)

// ==================== 存档模型（本地 JSON，结构对齐原版 novel_save.json） ====================

/** 可选的网文分类（多选，对齐主流阅读平台标签体系） */
object NovelCategories {
    val all = listOf(
        // 核心大类
        "玄幻", "奇幻", "武侠", "仙侠", "都市", "历史", "军事", "游戏", "体育",
        "科幻", "悬疑推理", "灵异惊悚", "言情", "二次元",
        // 玄幻细分
        "东方玄幻", "高武世界", "无敌流", "洪荒神话", "修仙", "修真", "剑道",
        "灵气复苏", "诸天万界", "异世大陆",
        // 奇幻细分
        "西方魔幻", "克苏鲁", "规则怪谈", "轻小说",
        // 末世科幻
        "末世废土", "末日求生", "星际", "赛博朋克", "黑科技",
        // 都市细分
        "都市异能", "都市修真", "都市脑洞", "神豪", "发家致富", "种田", "经营",
        "美食", "直播", "娱乐圈", "职场", "乡村", "家庭伦理",
        // 悬疑灵异
        "盗墓", "鉴宝", "风水秘术", "捉鬼", "推理破案",
        // 历史军事
        "架空历史", "三国", "大唐", "宋朝", "明朝", "民国", "科举仕途", "争霸",
        "谍战", "抗战",
        // 设定流派
        "系统流", "签到流", "无限流", "副本流", "重生", "穿越", "穿书", "快穿",
        // 角色情节
        "赘婿", "神医", "女强", "大女主", "群像", "奶爸", "天才流", "扮猪吃虎",
        "升级流", "单女主", "无女主", "爽文打脸",
        // 衍生与其他
        "综漫同人", "电竞", "网游", "卡牌流", "惊悚游戏",
    )
}

@Serializable
data class NovelSave(
    @SerialName("book_setting") val bookSetting: String = "",
    @SerialName("character_setting") val characterSetting: String = "",
    @SerialName("main_plot") val mainPlot: String = "",
    @SerialName("last_chapter_content") val lastChapterContent: String = "",
    @SerialName("now_chapter") val nowChapter: Int = 0,
    @SerialName("meme_foreshadow") val memeForeshadow: List<ForeshadowData> = emptyList(),
    @SerialName("categories") val categories: List<String> = emptyList(),
    @SerialName("outline") val outline: String = "",
)

@Serializable
data class ForeshadowData(
    val content: String = "",
    @SerialName("bury_chapter") val buryChapter: Int = 0,
    @SerialName("plan_recycle_chapter") val planRecycleChapter: Int = 0,
    val type: String = "",
    val level: String = "",
    val status: String = "未回收",
    @SerialName("actual_recycle_chapter") val actualRecycleChapter: Int? = null,
)

// ==================== 本地梗库 ====================

/** 一条融梗素材 */
@Serializable
data class MemeItem(
    val content: String = "",
    val source: String = "hot", // hot=热梗抓取 / manual=手动添加
    @SerialName("collected_at") val collectedAt: Long = 0L,
    @SerialName("used_count") val usedCount: Int = 0,
)

/** 本地梗库容器（存 meme_lib.json） */
@Serializable
data class MemeLibrary(
    val items: List<MemeItem> = emptyList(),
)

// ==================== 生成请求/结果 ====================

@Serializable
data class GenerateOptions(
    @SerialName("word_count") val wordCount: Int = 1800,
    @SerialName("enable_foreshadow") val enableForeshadow: Boolean = false,
    @SerialName("foreshadow_type") val foreshadowType: String = "short",
    @SerialName("custom_meme") val customMeme: String = "",
    @SerialName("meme_level") val memeLevel: String = "adapt",
)

data class ChapterResult(
    val chapterNum: Int = 0,
    val chapterContent: String = "",
    val foreshadowAction: String = "none", // recycle / bury / none
    val relatedMeme: List<String> = emptyList(),
    val memeLevel: String = "",
    val checkPass: Boolean = false,
)

/**
 * 待确认章节：生成完成后先返回给用户检查，
 * 用户点"确认保存"后才写入存档；放弃则全部丢弃。
 */
data class PendingChapter(
    val chapterNum: Int,
    val chapterContent: String,
    val foreshadowAction: String,
    val relatedMeme: List<String>,
    val memeLevel: String,
    val checkPass: Boolean,
    /** 生成时已到期、待标记回收的伏笔埋入章 */
    val recycleBuryChapters: List<Int>,
    /** 待新埋入的伏笔（无则 null） */
    val newForeshadow: ForeshadowData?,
    /** 生成时的存档快照，确认保存时基于它更新 */
    val saveSnapshot: NovelSave,
)

/** 润色结果：三段设定按标记拆分后的文本 */
data class PolishResult(
    val bookSetting: String,
    val characterSetting: String,
    val mainPlot: String,
)
