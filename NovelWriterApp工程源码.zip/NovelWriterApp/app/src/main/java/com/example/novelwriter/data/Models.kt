package com.example.novelwriter.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// ==================== 大模型接口（OpenAI 兼容） ====================

@Serializable
data class ChatMessage(
    val role: String,
    val content: String,
)

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.65,
    @SerialName("max_tokens") val maxTokens: Int = 3600,
)

@Serializable
data class ChatResponse(
    val choices: List<ChatChoice> = emptyList(),
    val error: ChatError? = null,
)

@Serializable
data class ChatChoice(
    val message: ChatMessage = ChatMessage("assistant", ""),
)

@Serializable
data class ChatError(
    val message: String = "",
    val type: String = "",
)

// ==================== 存档模型（本地 JSON，结构对齐原版 novel_save.json） ====================

@Serializable
data class NovelSave(
    @SerialName("book_setting") val bookSetting: String = "",
    @SerialName("character_setting") val characterSetting: String = "",
    @SerialName("main_plot") val mainPlot: String = "",
    @SerialName("last_chapter_content") val lastChapterContent: String = "",
    @SerialName("now_chapter") val nowChapter: Int = 0,
    @SerialName("meme_foreshadow") val memeForeshadow: List<ForeshadowData> = emptyList(),
)

@Serializable
data class ForeshadowData(
    val content: String = "",
    @SerialName("bury_chapter") val buryChapter: Int = 0,
    @SerialName("plan_recycle_chapter") val planRecycleChapter: Int = 0,
    val type: String = "",
    val level: String = "",
    val status: String = "未回收",
    @SerialName("actual_recycle_chapter") val actualRecycleChapter: Int? = null,
)

// ==================== 生成请求/结果 ====================

@Serializable
data class GenerateOptions(
    @SerialName("word_count") val wordCount: Int = 1800,
    @SerialName("enable_foreshadow") val enableForeshadow: Boolean = false,
    @SerialName("foreshadow_type") val foreshadowType: String = "short",
    @SerialName("custom_meme") val customMeme: String = "",
    @SerialName("meme_level") val memeLevel: String = "adapt",
)

data class ChapterResult(
    val chapterNum: Int = 0,
    val chapterContent: String = "",
    val foreshadowAction: String = "none", // recycle / bury / none
    val relatedMeme: List<String> = emptyList(),
    val memeLevel: String = "",
    val checkPass: Boolean = false,
)
