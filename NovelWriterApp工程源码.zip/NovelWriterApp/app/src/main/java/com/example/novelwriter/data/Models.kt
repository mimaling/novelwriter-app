package com.example.novelwriter.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// ==================== 大模型接口（OpenAI 兼容） ====================

@Serializable
data class ChatMessage(
    val role: String,
    val content: String,
)

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    val temperature: Double = 0.65,
    @SerialName("max_tokens") val maxTokens: Int = 3600,
)

@Serializable
data class ChatResponse(
    val choices: List<ChatChoice> = emptyList(),
    val error: ChatError? = null,
)

@Serializable
data class ChatChoice(
    val message: ChatMessage = ChatMessage("assistant", ""),
)

@Serializable
data class ChatError(
    val message: String = "",
    val type: String = "",
)

// ==================== 存档模型（本地 JSON，结构对齐原版 novel_save.json） ====================

/** 可选的网文分类（多选） */
object NovelCategories {
    val all = listOf(
        "玄幻", "奇幻", "武侠", "仙侠", "都市", "历史", "军事",
        "游戏", "体育", "科幻", "悬疑推理", "灵异惊悚", "言情", "二次元",
    )
}

@Serializable
data class NovelSave(
    @SerialName("book_setting") val bookSetting: String = "",
    @SerialName("character_setting") val characterSetting: String = "",
    @SerialName("main_plot") val mainPlot: String = "",
    @SerialName("last_chapter_content") val lastChapterContent: String = "",
    @SerialName("now_chapter") val nowChapter: Int = 0,
    @SerialName("meme_foreshadow") val memeForeshadow: List<ForeshadowData> = emptyList(),
    @SerialName("categories") val categories: List<String> = emptyList(),
    @SerialName("outline") val outline: String = "",
)

@Serializable
data class ForeshadowData(
    val content: String = "",
    @SerialName("bury_chapter") val buryChapter: Int = 0,
    @SerialName("plan_recycle_chapter") val planRecycleChapter: Int = 0,
    val type: String = "",
    val level: String = "",
    val status: String = "未回收",
    @SerialName("actual_recycle_chapter") val actualRecycleChapter: Int? = null,
)

// ==================== 本地梗库 ====================

/** 一条融梗素材 */
@Serializable
data class MemeItem(
    val content: String = "",
    val source: String = "hot", // hot=热梗抓取 / manual=手动添加
    @SerialName("collected_at") val collectedAt: Long = 0L,
    @SerialName("used_count") val usedCount: Int = 0,
)

/** 本地梗库容器（存 meme_lib.json） */
@Serializable
data class MemeLibrary(
    val items: List<MemeItem> = emptyList(),
)

// ==================== 生成请求/结果 ====================

@Serializable
data class GenerateOptions(
    @SerialName("word_count") val wordCount: Int = 1800,
    @SerialName("enable_foreshadow") val enableForeshadow: Boolean = false,
    @SerialName("foreshadow_type") val foreshadowType: String = "short",
    @SerialName("custom_meme") val customMeme: String = "",
    @SerialName("meme_level") val memeLevel: String = "adapt",
)

data class ChapterResult(
    val chapterNum: Int = 0,
    val chapterContent: String = "",
    val foreshadowAction: String = "none", // recycle / bury / none
    val relatedMeme: List<String> = emptyList(),
    val memeLevel: String = "",
    val checkPass: Boolean = false,
)

/**
 * 待确认章节：生成完成后先返回给用户检查，
 * 用户点"确认保存"后才写入存档；放弃则全部丢弃。
 */
data class PendingChapter(
    val chapterNum: Int,
    val chapterContent: String,
    val foreshadowAction: String,
    val relatedMeme: List<String>,
    val memeLevel: String,
    val checkPass: Boolean,
    /** 生成时已到期、待标记回收的伏笔埋入章 */
    val recycleBuryChapters: List<Int>,
    /** 待新埋入的伏笔（无则 null） */
    val newForeshadow: ForeshadowData?,
    /** 生成时的存档快照，确认保存时基于它更新 */
    val saveSnapshot: NovelSave,
)

/** 润色结果：三段设定按标记拆分后的文本 */
data class PolishResult(
    val bookSetting: String,
    val characterSetting: String,
    val mainPlot: String,
)
