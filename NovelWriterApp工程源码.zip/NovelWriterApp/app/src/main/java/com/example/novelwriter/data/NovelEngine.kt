package com.example.novelwriter.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * 单章闭环小说生成引擎（原后端逻辑的 Kotlin 移植版）。
 *
 * 全部在手机本地完成：全局设定锁、梗伏笔池、隐式融梗、AI缺陷防御、自动重试、JSON存档。
 * 仅大模型推理调用云端 OpenAI 兼容接口。
 */
class NovelEngine(
    private val store: NovelStore,
    private val settings: SettingsStore,
) {

    // ---- 配置常量（与原版一致） ----
    private val shortRecycleRange = 2..4
    private val longRecycleRange = 15..30
    private val maxUnrecycled = 3
    private val defaultMemeLevel = "adapt"
    private val hotMemeUrl = "https://api.vvhan.com/api/hotlist/wb"
    private val bannedWords = listOf(
        "深邃的眼眸", "嘴角勾起", "不可否认", "然而", "心中一动",
        "冷哼一声", "淡淡道", "微微一笑", "摇了摇头", "叹了口气",
        "不由得", "殊不知",
    )

    private val json = Json { ignoreUnknownKeys = true }

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // ==================== 存档 ====================

    fun getSave(): NovelSave = store.load()

    suspend fun initNovel(bookSetting: String, characterSetting: String, mainPlot: String) {
        val save = store.loadAsync()
        store.saveAsync(
            save.copy(
                bookSetting = bookSetting,
                characterSetting = characterSetting,
                mainPlot = mainPlot,
            )
        )
    }

    // ==================== 工具函数 ====================

    /** 获取当日实时热梗，失败返回空列表，不影响主流程 */
    private suspend fun getDailyHotMemes(): List<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(hotMemeUrl).build()
            httpClient.newCall(request).execute().use { res ->
                if (!res.isSuccessful) return@withContext emptyList()
                val body = res.body?.string() ?: return@withContext emptyList()
                val root = json.parseToJsonElement(body).jsonObject
                val data = root["data"]?.jsonArray ?: return@withContext emptyList()
                data.mapNotNull { it.jsonObject["title"]?.jsonPrimitive?.content }
                    .take(20)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** 需要回收的伏笔 */
    private fun getRecycleForeshadows(nowChapter: Int, save: NovelSave): List<ForeshadowData> =
        save.memeForeshadow.filter {
            it.status == "未回收" && it.planRecycleChapter <= nowChapter
        }

    /** 是否还有名额埋入新伏笔 */
    private fun canBuryNew(save: NovelSave): Boolean =
        save.memeForeshadow.count { it.status == "未回收" } < maxUnrecycled

    // ==================== 三重校验 ====================

    data class TasteCheck(
        val bannedHit: List<String>,
        val sameStructureWarn: Boolean,
        val pass: Boolean,
    )

    /** AI陈词滥调与句式问题检测 */
    private fun checkAiTaste(content: String): TasteCheck {
        val hitWords = bannedWords.filter { content.countOccurrences(it) > 1 }

        val lines = content.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        var sameStructCount = 0
        for (i in 0..(lines.size - 3).coerceAtLeast(0)) {
            if (i + 2 >= lines.size) break
            val d1 = kotlin.math.abs(lines[i].length - lines[i + 1].length)
            val d2 = kotlin.math.abs(lines[i + 1].length - lines[i + 2].length)
            if (d1 < 5 && d2 < 5) sameStructCount++
        }
        val pass = hitWords.isEmpty() && sameStructCount <= 3
        return TasteCheck(hitWords, sameStructCount > 3, pass)
    }

    /** 核心设定一致性：主角名（人设第一行前8字符）必须出现在正文 */
    private fun checkSettingConsistency(content: String, save: NovelSave): Boolean {
        val firstLine = save.characterSetting.trim().split("\n").firstOrNull()?.trim() ?: return true
        if (firstLine.isBlank()) return true
        val protagKey = firstLine.take(8)
        return protagKey.isEmpty() || content.contains(protagKey)
    }

    /** 梗是否直白出现：命中则需重写 */
    private fun checkMemeExplicit(content: String, meme: String): Boolean =
        meme.isNotBlank() && content.contains(meme)

    // ==================== 核心生成 ====================

    /**
     * 生成下一章。流程：伏笔处理 → 组装提示词 → 调大模型 → 三重校验 → 失败重试一次 → 更新存档。
     */
    suspend fun generateNextChapter(options: GenerateOptions): ChapterResult = withContext(Dispatchers.IO) {
        val save = store.load()
        val nowNum = save.nowChapter + 1
        val lastText = save.lastChapterContent

        // ===== 伏笔逻辑处理 =====
        var foreshadowPrompt = ""
        var buryNew = false
        var selectedMeme = ""
        var planRecycle = 0
        var recycleList: List<ForeshadowData> = emptyList()
        val memeLevel = options.memeLevel.ifBlank { defaultMemeLevel }

        if (options.enableForeshadow) {
            recycleList = getRecycleForeshadows(nowNum, save)
            if (recycleList.isNotEmpty()) {
                val recycleText = recycleList.joinToString("\n") {
                    "- 第${it.buryChapter}章埋下的伏笔内核：${it.content}"
                }
                foreshadowPrompt =
                    """【本章需回收伏笔】$recycleText
要求：自然融入当前剧情进行呼应，不要生硬提及，回收后完成剧情闭环。"""
            } else if (canBuryNew(save)) {
                buryNew = true
                selectedMeme = if (options.customMeme.isNotBlank()) options.customMeme
                else getDailyHotMemes().randomOrNull() ?: ""
                if (selectedMeme.isNotBlank()) {
                    val range = if (options.foreshadowType == "long") longRecycleRange else shortRecycleRange
                    planRecycle = nowNum + Random.nextInt(range.first, range.last + 1)

                    val levelRule = if (memeLevel == "kernel") {
                        "仅提取核心冲突、情绪模式、人物关系，完全转化为剧情事件，全程看不出任何梗的痕迹"
                    } else {
                        "提取行为逻辑与场景内核，转化为符合人物身份的细节、对话、小动作，熟悉的人能会心一笑，普通读者只觉自然"
                    }

                    foreshadowPrompt =
                        """【本章埋下剧情伏笔】可用元素内核：$selectedMeme
【隐式融梗铁则（违者重写）】
1. 绝对禁止直接出现「$selectedMeme」原词、原句、网络流行语
2. $levelRule
3. 轻描淡写融入剧情，不要刻意强调，不要单独给镜头
4. 仅埋1处，不影响主线推进，不打断叙事节奏"""
                }
            }
        }

        // ===== 主体生成提示词 =====
        var prompt = if (nowNum == 1) {
            """你是专职网文作者，严格遵守所有规则，仅生成完整第一章，一次只写一章。
【全书世界观设定】${save.bookSetting}
【人物设定（绝对不能崩坏）】${save.characterSetting}
【主线剧情方向】${save.mainPlot}
$foreshadowPrompt
写作硬性规则：
1. 仅输出第1章完整正文，字数${options.wordCount}左右
2. 开局铺垫自然，埋下主线伏笔，人设严格贴合设定
3. 无解说、无大纲、无总结、不分点
4. 禁止使用陈词滥调，禁止模板化表达
5. 禁止提前剧透后续剧情"""
        } else {
            """严格执行：只写第$nowNum章，一次仅生成一章，绝对不多写。
【固定全书设定】世界观：${save.bookSetting}
人物设定：${save.characterSetting}
主线方向：${save.mainPlot}
【上一章完整原文（必须100%承接剧情）】$lastText
$foreshadowPrompt
写作硬性规则：
1. 完整承接上一章结尾剧情，衔接丝滑无断层
2. 延续人物性格与叙事节奏，绝不OOC
3. 回收前文伏笔，合理推进主线，不突兀新增剧情
4. 仅输出本章正文，${options.wordCount}字左右
5. 禁止使用陈词滥调，禁止模板化表达
6. 无任何多余文字，只给小说正文"""
        }

        // ===== 调用大模型（首次） =====
        var content = callLlm(prompt, options.wordCount)

        // ===== 三重校验 + 自动重试 =====
        val tasteCheck = checkAiTaste(content)
        val settingCheck = checkSettingConsistency(content, save)
        val memeExplicit = buryNew && checkMemeExplicit(content, selectedMeme)

        var finalTaste = tasteCheck
        var finalSetting = settingCheck
        var finalMemeExplicit = memeExplicit

        if (!tasteCheck.pass || !settingCheck || memeExplicit) {
            val fixNotes = mutableListOf<String>()
            if (!tasteCheck.pass) fixNotes.add("避免使用陈词滥调，句式长短错落")
            if (!settingCheck) fixNotes.add("严格遵守人物设定与世界观")
            if (memeExplicit) fixNotes.add("绝对禁止直接出现「$selectedMeme」原词，用剧情细节化用内核")

            prompt += "\n\n【修正要求】${fixNotes.joinToString("; ")}。重写本章。"
            content = callLlm(prompt, options.wordCount)
            finalTaste = checkAiTaste(content)
            finalSetting = checkSettingConsistency(content, save)
            finalMemeExplicit = buryNew && checkMemeExplicit(content, selectedMeme)
        }

        // ===== 更新伏笔池 =====
        var updatedForeshadows = save.memeForeshadow
        if (options.enableForeshadow) {
            if (recycleList.isNotEmpty()) {
                updatedForeshadows = updatedForeshadows.map { f ->
                    if (f.planRecycleChapter <= nowNum && f.status == "未回收") {
                        f.copy(status = "已回收", actualRecycleChapter = nowNum)
                    } else f
                }
            }
            if (buryNew && selectedMeme.isNotBlank()) {
                updatedForeshadows = updatedForeshadows + ForeshadowData(
                    content = selectedMeme,
                    buryChapter = nowNum,
                    planRecycleChapter = planRecycle,
                    type = options.foreshadowType,
                    level = memeLevel,
                    status = "未回收",
                )
            }
        }

        // ===== 更新存档 =====
        store.save(
            save.copy(
                nowChapter = nowNum,
                lastChapterContent = content,
                memeForeshadow = updatedForeshadows,
            )
        )

        ChapterResult(
            chapterNum = nowNum,
            chapterContent = content,
            foreshadowAction = if (recycleList.isNotEmpty()) "recycle" else if (buryNew) "bury" else "none",
            relatedMeme = if (buryNew) listOf(selectedMeme).filter { it.isNotBlank() }
            else recycleList.map { it.content },
            memeLevel = if (buryNew) memeLevel else "",
            checkPass = finalTaste.pass && finalSetting && !finalMemeExplicit,
        )
    }

    // ==================== LLM 调用 ====================

    private suspend fun callLlm(prompt: String, wordCount: Int): String {
        val apiKey = settings.apiKey
        require(apiKey.isNotBlank()) { "未配置 API Key，请先在服务设置中填写" }

        val request = ChatRequest(
            model = settings.modelName.ifBlank { "qwen3" },
            messages = listOf(ChatMessage("user", prompt)),
            temperature = 0.65,
            maxTokens = (wordCount * 2).coerceAtLeast(500),
        )
        val response = LlmClient.api.chatCompletion(
            LlmClient.buildChatUrl(settings.llmBaseUrl),
            LlmClient.authHeader(apiKey),
            request,
        )
        val error = response.error
        if (error != null && error.message.isNotBlank()) {
            throw IllegalStateException("模型接口返回错误：${error.message}")
        }
        val content = response.choices.firstOrNull()?.message?.content?.trim().orEmpty()
        require(content.isNotBlank()) { "模型未返回正文内容" }
        return content
    }
}

/** 统计字符串出现次数 */
private fun String.countOccurrences(target: String): Int {
    if (target.isEmpty()) return 0
    var count = 0
    var index = indexOf(target)
    while (index >= 0) {
        count++
        index = indexOf(target, index + target.length)
    }
    return count
}
