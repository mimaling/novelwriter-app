package com.example.novelwriter

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.novelwriter.data.ChapterResult
import com.example.novelwriter.data.GenerateOptions
import com.example.novelwriter.data.NovelEngine
import com.example.novelwriter.data.NovelSave
import com.example.novelwriter.data.SettingsStore
import kotlinx.coroutines.launch

/**
 * 全局状态容器：集中管理各界面的数据与生成逻辑。
 */
class MainViewModel(
    private val engine: NovelEngine,
    private val settings: SettingsStore,
) : ViewModel() {

    // ---- 模型设置 ----
    var llmBaseUrl by mutableStateOf(settings.llmBaseUrl)
        private set
    var apiKey by mutableStateOf(settings.apiKey)
        private set
    var modelName by mutableStateOf(settings.modelName)
        private set
    fun updateLlmBaseUrl(value: String) { llmBaseUrl = value }
    fun updateApiKey(value: String) { apiKey = value }
    fun updateModelName(value: String) { modelName = value }
    fun saveSettings() {
        settings.llmBaseUrl = llmBaseUrl
        settings.apiKey = apiKey
        settings.modelName = modelName
    }

    // ---- 初始化 ----
    var initBookSetting by mutableStateOf("")
    var initCharacterSetting by mutableStateOf("")
    var initMainPlot by mutableStateOf("")
    var initMessage by mutableStateOf("")
    var initLoading by mutableStateOf(false)

    // ---- 生成 ----
    var wordCount by mutableStateOf("1800")
    var enableForeshadow by mutableStateOf(false)
    var foreshadowType by mutableStateOf("short")
    var customMeme by mutableStateOf("")
    var memeLevel by mutableStateOf("adapt")
    var chapterResult by mutableStateOf<ChapterResult?>(null)
    var generateLoading by mutableStateOf(false)

    // ---- 进度与伏笔 ----
    var save by mutableStateOf<NovelSave?>(null)
    var queryLoading by mutableStateOf(false)

    // ---- 通用 ----
    var errorMessage by mutableStateOf("")
    var noticeMessage by mutableStateOf("")

    init {
        refreshSave()
    }

    fun refreshSave() {
        save = engine.getSave()
    }

    /** 捕获异常并给出可读提示 */
    private fun runTask(
        loading: (Boolean) -> Unit,
        onErrorPrefix: String,
        onSuccess: (() -> Unit)? = null,
        block: suspend () -> Unit,
    ) {
        viewModelScope.launch {
            errorMessage = ""
            loading(true)
            try {
                block()
                onSuccess?.invoke()
            } catch (e: Exception) {
                errorMessage = "$onErrorPrefix：${e.message ?: e.javaClass.simpleName}"
            } finally {
                loading(false)
            }
        }
    }

    fun initNovel() {
        if (initBookSetting.isBlank() || initCharacterSetting.isBlank() || initMainPlot.isBlank()) {
            errorMessage = "初始化失败：三个设定字段均不能为空"
            return
        }
        runTask(
            loading = { initLoading = it },
            onErrorPrefix = "初始化失败",
        ) {
            engine.initNovel(initBookSetting, initCharacterSetting, initMainPlot)
            initMessage = "全书设定锁定成功，可开始逐章生成"
            refreshSave()
        }
    }

    fun generateChapter() {
        val count = wordCount.toIntOrNull()
        if (count == null || count < 100) {
            errorMessage = "生成失败：字数需为不小于100的整数"
            return
        }
        runTask(
            loading = { generateLoading = it },
            onErrorPrefix = "生成失败",
        ) {
            chapterResult = engine.generateNextChapter(
                GenerateOptions(
                    wordCount = count,
                    enableForeshadow = enableForeshadow,
                    foreshadowType = foreshadowType,
                    customMeme = customMeme,
                    memeLevel = memeLevel,
                )
            )
            refreshSave()
        }
    }

    fun queryProgressAndForeshadows() {
        runTask(
            loading = { queryLoading = it },
            onErrorPrefix = "查询失败",
        ) {
            refreshSave()
        }
    }
}
