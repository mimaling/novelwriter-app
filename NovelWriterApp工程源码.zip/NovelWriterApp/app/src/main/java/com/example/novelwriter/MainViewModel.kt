package com.example.novelwriter

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.novelwriter.data.ChapterResult
import com.example.novelwriter.data.GenerateOptions
import com.example.novelwriter.data.MemeItem
import com.example.novelwriter.data.NovelEngine
import com.example.novelwriter.data.NovelSave
import com.example.novelwriter.data.PendingChapter
import com.example.novelwriter.data.SettingsStore
import kotlinx.coroutines.launch

/**
 * 全局状态容器：集中管理各界面的数据与生成逻辑。
 */
class MainViewModel(
    private val engine: NovelEngine,
    private val settings: SettingsStore,
) : ViewModel() {

    // ---- 模型设置 ----
    var llmBaseUrl by mutableStateOf(settings.llmBaseUrl)
        private set
    var apiKey by mutableStateOf(settings.apiKey)
        private set
    var modelName by mutableStateOf(settings.modelName)
        private set
    fun updateLlmBaseUrl(value: String) { llmBaseUrl = value }
    fun updateApiKey(value: String) { apiKey = value }
    fun updateModelName(value: String) { modelName = value }
    fun saveSettings() {
        settings.llmBaseUrl = llmBaseUrl
        settings.apiKey = apiKey
        settings.modelName = modelName
    }

    // ---- 初始化 ----
    var initBookSetting by mutableStateOf("")
    var initCharacterSetting by mutableStateOf("")
    var initMainPlot by mutableStateOf("")
    var selectedCategories by mutableStateOf<List<String>>(emptyList())
    var initMessage by mutableStateOf("")
    var initLoading by mutableStateOf(false)

    // ---- 润色 ----
    var polishLoading by mutableStateOf(false)
    var polishTarget by mutableStateOf("")     // "book" / "character" / "plot"
    var polishResult by mutableStateOf("")    // 待用户确认的润色结果

    // ---- 大纲 ----
    var outlineLoading by mutableStateOf(false)
    var outlineResult by mutableStateOf("")   // 待用户确认的大纲

    // ---- 生成 ----
    var wordCount by mutableStateOf("1800")
    var enableForeshadow by mutableStateOf(false)
    var foreshadowType by mutableStateOf("short")
    var customMeme by mutableStateOf("")
    var memeLevel by mutableStateOf("adapt")
    var pendingChapter by mutableStateOf<PendingChapter?>(null)
    /** 待确认章节的可编辑草稿（用户可修改后保存） */
    var chapterDraft by mutableStateOf("")
    var lastConfirmedChapter by mutableStateOf<ChapterResult?>(null)
    var generateLoading by mutableStateOf(false)

    // ---- 梗库 ----
    var memeLibrary by mutableStateOf<List<MemeItem>>(emptyList())
    var newMemeText by mutableStateOf("")
    var collectMemeLoading by mutableStateOf(false)

    // ---- 进度与伏笔 ----
    var save by mutableStateOf<NovelSave?>(null)
    var queryLoading by mutableStateOf(false)

    // ---- 通用 ----
    var errorMessage by mutableStateOf("")
    var noticeMessage by mutableStateOf("")

    init {
        refreshSave()
        refreshMemeLibrary()
    }

    fun refreshSave() {
        save = engine.getSave()
        // 初始化页回填已锁定的设定与分类
        save?.let {
            if (initBookSetting.isBlank() && it.bookSetting.isNotBlank()) initBookSetting = it.bookSetting
            if (initCharacterSetting.isBlank() && it.characterSetting.isNotBlank()) initCharacterSetting = it.characterSetting
            if (initMainPlot.isBlank() && it.mainPlot.isNotBlank()) initMainPlot = it.mainPlot
            if (selectedCategories.isEmpty() && it.categories.isNotEmpty()) selectedCategories = it.categories
        }
    }

    fun toggleCategory(category: String) {
        selectedCategories = if (category in selectedCategories) {
            selectedCategories - category
        } else {
            selectedCategories + category
        }
    }

    /** 捕获异常并给出可读提示 */
    private fun runTask(
        loading: (Boolean) -> Unit,
        onErrorPrefix: String,
        onSuccess: (() -> Unit)? = null,
        block: suspend () -> Unit,
    ) {
        viewModelScope.launch {
            errorMessage = ""
            loading(true)
            try {
                block()
                onSuccess?.invoke()
            } catch (e: Exception) {
                errorMessage = "$onErrorPrefix：${e.message ?: e.javaClass.simpleName}"
            } finally {
                loading(false)
            }
        }
    }

    fun initNovel() {
        if (initBookSetting.isBlank() || initCharacterSetting.isBlank() || initMainPlot.isBlank()) {
            errorMessage = "初始化失败：三个设定字段均不能为空"
            return
        }
        if (selectedCategories.isEmpty()) {
            errorMessage = "初始化失败：请至少选择一个分类"
            return
        }
        runTask(
            loading = { initLoading = it },
            onErrorPrefix = "初始化失败",
        ) {
            engine.initNovel(initBookSetting, initCharacterSetting, initMainPlot, selectedCategories)
            initMessage = "全书设定锁定成功，可开始生成大纲或逐章生成"
            refreshSave()
        }
    }

    // ---- 润色 ----

    fun polishField(target: String) {
        val text = when (target) {
            "book" -> initBookSetting
            "character" -> initCharacterSetting
            else -> initMainPlot
        }
        if (text.isBlank()) {
            errorMessage = "请先填写要润色的内容"
            return
        }
        if (selectedCategories.isEmpty()) {
            errorMessage = "请先至少选择一个分类，再执行润色"
            return
        }
        runTask(
            loading = { polishLoading = it },
            onErrorPrefix = "润色失败",
        ) {
            polishTarget = target
            polishResult = engine.polishSetting(text, selectedCategories)
        }
    }

    fun applyPolish() {
        when (polishTarget) {
            "book" -> initBookSetting = polishResult
            "character" -> initCharacterSetting = polishResult
            else -> initMainPlot = polishResult
        }
        noticeMessage = "已应用润色结果"
        polishResult = ""
    }

    fun dismissPolish() {
        polishResult = ""
        polishTarget = ""
    }

    // ---- 大纲 ----

    fun generateOutline() {
        runTask(
            loading = { outlineLoading = it },
            onErrorPrefix = "生成大纲失败",
        ) {
            val current = engine.getSave()
            outlineResult = engine.generateOutline(current)
        }
    }

    fun applyOutline() {
        runTask(
            loading = { outlineLoading = it },
            onErrorPrefix = "保存大纲失败",
        ) {
            engine.saveOutline(outlineResult)
            noticeMessage = "大纲已保存，后续章节将按大纲推进"
            outlineResult = ""
            refreshSave()
        }
    }

    fun dismissOutline() {
        outlineResult = ""
    }

    // ---- 生成 ----

    fun generateChapter() {
        val count = wordCount.toIntOrNull()
        if (count == null || count < 100) {
            errorMessage = "生成失败：字数需为不小于100的整数"
            return
        }
        runTask(
            loading = { generateLoading = it },
            onErrorPrefix = "生成失败",
        ) {
            val generated = engine.generateNextChapter(
                GenerateOptions(
                    wordCount = count,
                    enableForeshadow = enableForeshadow,
                    foreshadowType = foreshadowType,
                    customMeme = customMeme,
                    memeLevel = memeLevel,
                )
            )
            pendingChapter = generated
            chapterDraft = generated.chapterContent
        }
    }

    /** 用户检查（可修改）通过后确认保存 */
    fun confirmChapter() {
        val pending = pendingChapter ?: return
        runTask(
            loading = { generateLoading = it },
            onErrorPrefix = "保存失败",
        ) {
            engine.confirmChapter(pending, chapterDraft.ifBlank { pending.chapterContent })
            lastConfirmedChapter = ChapterResult(
                chapterNum = pending.chapterNum,
                chapterContent = chapterDraft.ifBlank { pending.chapterContent },
                foreshadowAction = pending.foreshadowAction,
                relatedMeme = pending.relatedMeme,
                memeLevel = pending.memeLevel,
                checkPass = pending.checkPass,
            )
            pendingChapter = null
            chapterDraft = ""
            noticeMessage = "第${pending.chapterNum}章已保存"
            refreshSave()
        }
    }

    /** 放弃本次生成结果 */
    fun discardChapter() {
        pendingChapter = null
        chapterDraft = ""
    }

    fun queryProgressAndForeshadows() {
        runTask(
            loading = { queryLoading = it },
            onErrorPrefix = "查询失败",
        ) {
            refreshSave()
        }
    }

    // ---- 梗库 ----

    fun refreshMemeLibrary() {
        memeLibrary = engine.getMemeLibrary()
    }

    /** 一键抓取当日热梗入库 */
    fun collectHotMemes() {
        runTask(
            loading = { collectMemeLoading = it },
            onErrorPrefix = "抓取热梗失败",
        ) {
            val added = engine.collectHotMemes()
            noticeMessage = if (added > 0) "已抓取 $added 条热梗入库" else "没有新增热梗（可能已全部在库）"
            refreshMemeLibrary()
        }
    }

    /** 手动添加一条梗 */
    fun addMeme() {
        runTask(
            loading = { collectMemeLoading = it },
            onErrorPrefix = "添加失败",
        ) {
            engine.addManualMeme(newMemeText)
            newMemeText = ""
            refreshMemeLibrary()
        }
    }

    /** 从本地库删除一条梗 */
    fun deleteMeme(content: String) {
        runTask(
            loading = { collectMemeLoading = it },
            onErrorPrefix = "删除失败",
        ) {
            engine.deleteMeme(content)
            refreshMemeLibrary()
        }
    }
}
