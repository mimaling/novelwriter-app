package com.example.novelwriter.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 本地梗库：融梗素材以 JSON 文件保存在 APP 私有目录（meme_lib.json），重启不丢失。
 * 来源：手动添加 / 一键抓取当日热梗；生成章节时自动从中取材。
 */
class MemeStore(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val memeFile: File =
        File(context.applicationContext.filesDir, "meme_lib.json")

    fun load(): MemeLibrary {
        return try {
            if (memeFile.exists()) {
                json.decodeFromString<MemeLibrary>(memeFile.readText())
            } else {
                MemeLibrary()
            }
        } catch (e: Exception) {
            MemeLibrary()
        }
    }

    fun save(data: MemeLibrary) {
        try {
            memeFile.writeText(json.encodeToString(MemeLibrary.serializer(), data))
        } catch (e: Exception) {
            // 保存失败不影响主流程
        }
    }

    suspend fun loadAsync(): MemeLibrary = withContext(Dispatchers.IO) { load() }

    suspend fun saveAsync(data: MemeLibrary) = withContext(Dispatchers.IO) { save(data) }
}
