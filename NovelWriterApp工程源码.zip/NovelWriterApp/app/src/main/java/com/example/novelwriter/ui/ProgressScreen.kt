package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel
import com.example.novelwriter.data.ForeshadowData

/** 界面四：进度与伏笔状态 */
@Composable
fun ProgressScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("进度与伏笔", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { viewModel.queryProgressAndForeshadows() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.queryLoading,
        ) {
            if (viewModel.queryLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("刷新")
            }
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        viewModel.save?.let { s ->
            Spacer(Modifier.height(16.dp))
            Text("当前章节：第${s.nowChapter}章", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            val unrecycled = s.memeForeshadow.count { it.status == "未回收" }
            Text("未回收伏笔：$unrecycled 个", style = MaterialTheme.typography.bodyLarge)
            if (s.categories.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("分类：${s.categories.joinToString("、")}", style = MaterialTheme.typography.bodyMedium)
            }
            if (s.bookSetting.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("世界观：${s.bookSetting}", style = MaterialTheme.typography.bodyMedium)
            }
            if (s.outline.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("大纲：已生成并启用", style = MaterialTheme.typography.bodyMedium)
            }
        }

        viewModel.save?.let { s ->
            Spacer(Modifier.height(16.dp))
            Divider()
            Spacer(Modifier.height(8.dp))
            Text("伏笔池（共${s.memeForeshadow.size}条，未回收${s.memeForeshadow.count { it.status == "未回收" }}条）", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (s.memeForeshadow.isEmpty()) {
                Text("暂无伏笔记录", style = MaterialTheme.typography.bodyMedium)
            } else {
                s.memeForeshadow.forEach { item ->
                    ForeshadowRow(item)
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun ForeshadowRow(item: ForeshadowData) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            "梗：${item.content}（第${item.buryChapter}章埋下）",
            style = MaterialTheme.typography.bodyLarge,
        )
        Text(
            "计划第${item.planRecycleChapter}章回收 · ${item.type} · ${item.level} · ${item.status}" +
                (item.actualRecycleChapter?.let { " · 实际回收于第${it}章" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
