package com.example.novelwriter.data

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

/**
 * 大模型直连接口（OpenAI 兼容格式）。
 * baseUrl 在运行时由用户配置，可用 DeepSeek / 通义 / 豆包等任意 OpenAI 兼容端点。
 */
interface LlmApi {

    @POST
    suspend fun chatCompletion(
        @Url url: String,
        @Header("Authorization") auth: String,
        @Body body: ChatRequest,
    ): ChatResponse
}

object LlmClient {

    private val json = Json {
        ignoreUnknownKeys = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS) // 长文生成较慢，放宽读取超时
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openai.com/v1/")
        .client(okHttpClient)
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()

    val api: LlmApi = retrofit.create(LlmApi::class.java)

    /**
     * 将用户填写的接口地址规范化为完整 chat/completions URL。
     * 支持传入：完整地址、带 /v1 的地址、仅域名。
     */
    fun buildChatUrl(baseUrl: String): String {
        var trimmed = baseUrl.trim().trimEnd('/')
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
            trimmed = "https://$trimmed"
        }
        // 若已含 chat/completions 则直接用
        if (trimmed.endsWith("/chat/completions")) return trimmed
        // 若含 /v1 则补 chat/completions
        if (trimmed.contains("/v1")) return "$trimmed/chat/completions"
        // 否则补 /v1/chat/completions
        return "$trimmed/v1/chat/completions"
    }

    fun authHeader(apiKey: String): String = "Bearer $apiKey"
}
