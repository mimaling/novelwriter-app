package com.example.novelwriter.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 本地存档：全书状态以 JSON 文件保存在 APP 私有目录，重启不丢失。
 * 结构对齐原版 novel_save.json。
 */
class NovelStore(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val saveFile: File =
        File(context.applicationContext.filesDir, "novel_save.json")

    fun load(): NovelSave {
        return try {
            if (saveFile.exists()) {
                json.decodeFromString<NovelSave>(saveFile.readText())
            } else {
                NovelSave()
            }
        } catch (e: Exception) {
            NovelSave()
        }
    }

    fun save(data: NovelSave) {
        try {
            saveFile.writeText(json.encodeToString(NovelSave.serializer(), data))
        } catch (e: Exception) {
            // 存档失败不影响主流程，下次仍可重写
        }
    }

    suspend fun loadAsync(): NovelSave = withContext(Dispatchers.IO) { load() }

    suspend fun saveAsync(data: NovelSave) = withContext(Dispatchers.IO) { save(data) }
}
