package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel

/** 界面三：生成下一章（全参数） */
@Composable
fun GenerateScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("生成下一章", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = viewModel.wordCount,
            onValueChange = { viewModel.wordCount = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("字数（默认1800）") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("启用梗伏笔")
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = viewModel.enableForeshadow,
                onCheckedChange = { viewModel.enableForeshadow = it },
            )
        }
        Spacer(Modifier.height(8.dp))

        if (viewModel.enableForeshadow) {
            Text("伏笔类型", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.selectableGroup()) {
                Option("short", "短期（2-4章回收）", viewModel.foreshadowType) {
                    viewModel.foreshadowType = "short"
                }
                Option("long", "长期（15-30章回收）", viewModel.foreshadowType) {
                    viewModel.foreshadowType = "long"
                }
            }
            Spacer(Modifier.height(8.dp))

            Text("融梗等级", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.selectableGroup()) {
                Option("adapt", "化用级", viewModel.memeLevel) { viewModel.memeLevel = "adapt" }
                Option("kernel", "内核级", viewModel.memeLevel) { viewModel.memeLevel = "kernel" }
            }
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = viewModel.customMeme,
                onValueChange = { viewModel.customMeme = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("自定义梗（留空则自动取当日热梗）") },
                singleLine = true,
            )
            Spacer(Modifier.height(12.dp))
        }

        Button(
            onClick = { viewModel.generateChapter() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.generateLoading,
        ) {
            if (viewModel.generateLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("生成（需等待数十秒）")
            }
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        viewModel.chapterResult?.let { result ->
            Spacer(Modifier.height(16.dp))
            Text(
                "第${result.chapterNum}章 · 校验通过：${if (result.checkPass) "是" else "否"}",
                style = MaterialTheme.typography.titleSmall,
            )
            if (result.foreshadowAction.isNotBlank() && result.foreshadowAction != "none") {
                Spacer(Modifier.height(4.dp))
                Text(
                    "伏笔动作：${when (result.foreshadowAction) {
                        "recycle" -> "回收伏笔"
                        "bury" -> "埋入新伏笔"
                        else -> result.foreshadowAction
                    }}${if (result.relatedMeme.isNotEmpty()) "（${result.relatedMeme.joinToString("、")}）" else ""}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                result.chapterContent,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun Option(label: String, text: String, selectedValue: String, onSelect: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .selectable(
                selected = selectedValue == label,
                onClick = onSelect,
            )
            .padding(end = 16.dp),
    ) {
        RadioButton(
            selected = selectedValue == label,
            onClick = null,
        )
        Text(text)
    }
}
