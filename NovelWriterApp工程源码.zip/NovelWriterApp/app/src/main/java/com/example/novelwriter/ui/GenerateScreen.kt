package com.example.novelwriter.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.novelwriter.MainViewModel

/** 界面三：生成下一章（生成后先检查，确认后才保存） */
@Composable
fun GenerateScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Text("生成下一章", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "生成结果会先展示给你检查，点「确认保存」才写入存档；不满意可重新生成或放弃。",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = viewModel.wordCount,
            onValueChange = { viewModel.wordCount = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("字数（默认1800）") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("启用梗伏笔")
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = viewModel.enableForeshadow,
                onCheckedChange = { viewModel.enableForeshadow = it },
            )
        }
        Spacer(Modifier.height(8.dp))

        if (viewModel.enableForeshadow) {
            Text("伏笔类型", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.selectableGroup()) {
                Option("short", "短期（2-4章回收）", viewModel.foreshadowType) {
                    viewModel.foreshadowType = "short"
                }
                Option("long", "长期（15-30章回收）", viewModel.foreshadowType) {
                    viewModel.foreshadowType = "long"
                }
            }
            Spacer(Modifier.height(8.dp))

            Text("融梗等级", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.selectableGroup()) {
                Option("adapt", "化用级", viewModel.memeLevel) { viewModel.memeLevel = "adapt" }
                Option("kernel", "内核级", viewModel.memeLevel) { viewModel.memeLevel = "kernel" }
            }
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = viewModel.customMeme,
                onValueChange = { viewModel.customMeme = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("自定义梗（留空则从本地梗库自动取）") },
                singleLine = true,
            )
            Spacer(Modifier.height(12.dp))
        }

        Button(
            onClick = { viewModel.generateChapter() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !viewModel.generateLoading && viewModel.pendingChapter == null,
        ) {
            if (viewModel.generateLoading) {
                CircularProgressIndicator(modifier = Modifier.height(20.dp))
            } else {
                Text("生成（需等待数十秒）")
            }
        }
        viewModel.errorMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        // ---- 待检查的生成结果 ----
        viewModel.pendingChapter?.let { pending ->
            Spacer(Modifier.height(16.dp))
            Text(
                "第${pending.chapterNum}章 · 请检查后确认保存",
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "AI质量校验：${if (pending.checkPass) "通过" else "未通过（已自动重写一次，建议人工检查）"}",
                style = MaterialTheme.typography.bodyMedium,
                color = if (pending.checkPass) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error,
            )
            if (pending.safetyIssues.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "内容安全：检测到疑似违规词「${pending.safetyIssues.joinToString("、")}」，已要求模型重写；请确认正文无违规内容后再保存",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            if (pending.foreshadowAction.isNotBlank() && pending.foreshadowAction != "none") {
                Spacer(Modifier.height(4.dp))
                Text(
                    "伏笔动作：${when (pending.foreshadowAction) {
                        "recycle" -> "回收伏笔"
                        "bury" -> "埋入新伏笔"
                        else -> pending.foreshadowAction
                    }}${if (pending.relatedMeme.isNotEmpty()) "（${pending.relatedMeme.joinToString("、")}）" else ""}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "正文（可直接修改后保存）",
                style = MaterialTheme.typography.titleSmall,
            )
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = viewModel.chapterDraft,
                onValueChange = { viewModel.chapterDraft = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                textStyle = MaterialTheme.typography.bodyMedium,
            )

            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { viewModel.confirmChapter() },
                    modifier = Modifier.weight(1f),
                    enabled = !viewModel.generateLoading,
                ) {
                    if (viewModel.generateLoading) {
                        CircularProgressIndicator(modifier = Modifier.height(20.dp))
                    } else {
                        Text("确认保存")
                    }
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { viewModel.discardChapter() },
                    modifier = Modifier.weight(1f),
                    enabled = !viewModel.generateLoading,
                ) {
                    Text("放弃本章")
                }
            }
        }

        // ---- 已保存提示 ----
        viewModel.noticeMessage.takeIf { it.isNotBlank() }?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun Option(label: String, text: String, selectedValue: String, onSelect: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .selectable(
                selected = selectedValue == label,
                onClick = onSelect,
            )
            .padding(end = 16.dp),
    ) {
        RadioButton(
            selected = selectedValue == label,
            onClick = null,
        )
        Text(text)
    }
}
