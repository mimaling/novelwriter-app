# Retrofit / OkHttp / kotlinx.serialization 需要保留的规则
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*

# kotlinx.serialization
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.novelwriter.**$$serializer { *; }
-keepclassmembers class com.example.novelwriter.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.novelwriter.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Retrofit 接口
-keep,allowobfuscation,allowshrinking interface com.example.novelwriter.data.LlmApi
