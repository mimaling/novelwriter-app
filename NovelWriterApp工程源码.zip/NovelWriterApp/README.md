# 单章闭环式小说生成器（安卓 APP · 全云直连版）

把「单章闭环式小说生成 API」的**全部逻辑搬进手机**，只把大模型推理调用云端接口的安卓客户端。
一台手机即可写完整本书，无需电脑、无需服务器。

## 功能

- 大模型设置：填接口地址 + API Key + 模型名，直连云端（OpenAI 兼容格式）
- 全书初始化：世界观 / 人物设定 / 主线方向（全局设定锁）
- 生成章节：字数、伏笔开关、伏笔类型（短期/长期）、融梗等级（化用/内核）、自定义梗
- AI 缺陷防御：陈词滥调黑名单检测、句式多样性校验、设定一致性校验、融梗直白度校验，不过自动重写一次
- 梗伏笔池：自动埋设、到期回收、状态全程可查
- 本地存档：全书状态存手机 JSON 文件，重启不丢失

## 技术栈

- Kotlin + Jetpack Compose
- Retrofit + OkHttp + kotlinx.serialization（直连大模型 OpenAI 兼容接口）
- 构建：Gradle 8.5 / AGP 8.2.2 / JDK 17

## 支持的模型（任选其一，填对应接口地址与模型名）

| 服务 | 接口地址 | 模型名示例 | 获取 Key |
|---|---|---|---|
| DeepSeek | https://api.deepseek.com | deepseek-chat | platform.deepseek.com |
| 通义千问 | https://dashscope.aliyuncs.com/compatible-mode/v1 | qwen-plus | bailian.console.aliyun.com |
| 豆包(火山方舟) | https://ark.cn-beijing.volces.com/api/v3 | 你的接入点ID | console.volcengine.com/ark |
| OpenAI | https://api.openai.com/v1 | gpt-4o-mini | platform.openai.com |

## 快速开始

### 方式一：GitHub Actions 云端打包（推荐，全程手机即可）

无需电脑。手机浏览器按以下步骤操作：

1. 打开 github.com，注册/登录（免费账号即可）；
2. 新建仓库（Repository，名称随意，Public 即可）；
3. 进入仓库 → 点 **Add file** → **Upload files** → 上传本工程 zip（`NovelWriterApp工程源码.zip`）→ 点 **Commit changes**；
4. 点仓库顶部 **Actions** 标签 → 左侧选 **Build APK** → 右侧 **Run workflow** → 绿色按钮开始；
5. 等待约 10–20 分钟（首次需下载依赖），完成后在本次运行页面底部 **Artifacts** 处下载 `app-debug-apk.zip`；
6. 手机解压得到 `app-debug.apk`，点击安装。

### 方式二：电脑本地打包

```bash
chmod +x build_apk.sh
./build_apk.sh
```

脚本会自动检查 JDK 17、安装 Android SDK、生成 Gradle Wrapper 并构建。
产物：`app/build/outputs/apk/debug/app-debug.apk`

> 注意：Android Gradle Plugin 8.x 要求 JDK 17，Java 11 无法构建。

### 3. 安装与使用（只需一台手机）

1. 把 APK 传到手机安装；
2. 打开 APP → 「服务设置」，填入接口地址、API Key、模型名，保存；
3. 「全书初始化」填写世界观、人设、主线并锁定；
4. 「生成章节」按需设置参数，点击生成；
5. 「进度与伏笔」查看章节数与伏笔池状态。

## 目录结构

```
NovelWriterApp/
├── .github/workflows/build-apk.yml  # GitHub Actions 云端打包
├── build_apk.sh                    # 电脑本地一键打包脚本
├── settings.gradle.kts             # 工程配置
├── build.gradle.kts                # 插件版本
├── gradle/wrapper/                 # Gradle Wrapper
└── app/
    ├── build.gradle.kts            # 应用模块配置
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml     # INTERNET 权限 + 明文流量
        ├── java/com/example/novelwriter/
        │   ├── MainActivity.kt     # 入口 + 底部导航
        │   ├── MainViewModel.kt    # 全局状态与生成调度
        │   ├── MainViewModelFactory.kt
        │   ├── data/
        │   │   ├── Models.kt       # LLM请求/响应/存档数据类
        │   │   ├── LlmClient.kt    # 大模型直连（OpenAI兼容）
        │   │   ├── NovelEngine.kt  # 核心引擎（设定锁/伏笔池/校验/重试）
        │   │   ├── NovelStore.kt   # 手机本地 JSON 存档
        │   │   └── SettingsStore.kt
        │   └── ui/                 # 四个功能界面
        └── res/                    # 主题/图标/字符串
```
